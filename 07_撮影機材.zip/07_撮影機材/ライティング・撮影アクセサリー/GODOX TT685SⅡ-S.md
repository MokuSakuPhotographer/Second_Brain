﻿---
type: flash
名前: GODOX TT685SⅡ-S
カテゴリ: ライティング・撮影アクセサリー
メーカー: Godox
種類: クリップオンストロボ
対応: SONY用
ガイドナンバー: GN60（ISO100 / 200mm）
照射範囲: 20-200mm
発光モード: TTL / M / Multi
無線方式: Godox X 2.4GHz
同調速度: HSS 1/8000秒
リサイクルタイム: 0.1-2.6秒
source_urls:
  - "公式製品ページ: https://godox.com/product-d/TT685II.html"
関連機材:
  - "[[FOSOTO ライトスタンド アルミ製|FOSOTO ライトスタンド]]"
  - "[[SONY α7C|α7C]]"
  - "[[SONY α7Ⅳ|α7Ⅳ]]"
  - "[[SONY α7Ⅴ|α7Ⅴ]]"
  - "[[Godox X3S|Godox X3S]]"
tags:
  - ライティング
  - 撮影
  - Godox
  - ライティング撮影アクセサリー
aliases:
  - クリップオンストロボ
  - GODOX TT685SⅡ-S
  - TT685S
---
![[Godox TT685II-S.jpg|400]]


# GODOX TT685SⅡ-S

#ライティング #撮影 #Godox #ライティング撮影アクセサリー

## 基本情報

- **カテゴリ**: ライティング・撮影アクセサリー
- **メーカー**: Godox
## 対応機材
- [[FOSOTO ライトスタンド アルミ製|FOSOTO ライトスタンド]]
- [[SONY α7C|α7C]]
- [[SONY α7Ⅳ|α7Ⅳ]]
- [[SONY α7Ⅴ|α7Ⅴ]]
- [[Godox X3S|Godox X3S]]
## 仕様

- **種類**: クリップオンストロボ
- **対応**: SONY用
- **ガイドナンバー**: GN60（ISO100 / 200mm）
- **照射範囲**: 20-200mm
- **発光モード**: TTL / M / Multi
- **無線方式**: Godox X 2.4GHz
- **同調速度**: HSS 1/8000秒

## メモ

- 
