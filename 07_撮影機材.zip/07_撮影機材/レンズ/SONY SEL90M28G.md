﻿---
type: lens
メーカー: SONY
製品名: FE 90mm F2.8 Macro G OSS
モデル名: SEL90M28G
マウント: Sony E
対応センサー: フルサイズ
焦点距離: 90mm
35mm判換算_APS-C: 未確認
開放F値: F2.8
最小F値: F22
レンズ構成: 11群15枚
画角: 27°
画角_APS-C: 未確認
絞り羽根: 9枚（円形絞り）
最短撮影距離: 0.28m
最大撮影倍率: 1.0x（等倍）
フィルター径: φ62mm
最大径: φ79mm
全長: 130.5mm
重量: 602g
手ブレ補正: あり（Optical SteadyShot）
AF/MF: AF対応（DDSSM） / MF対応
AF駆動: DDSSM
防塵防滴: 防塵・防滴に配慮した設計
発売日: 2015-06-26
発売年: "2015"
所有状況: 所有
主な用途:
  - マクロ
  - ポートレート
  - 物撮り
  - テーブルフォト
  - 花
tags:
  - camera
  - lens
  - sony
  - g-lens
  - sony-e
  - full-frame
  - macro
  - prime
売却予定: false
購入日: 2022-01-19
購入価格: ¥106,800
source_urls:
  - "公式製品ページ: https://www.sony.jp/ichigan/products/SEL90M28G/"
  - "公式仕様ページ: https://www.sony-asia.com/electronics/camera-lenses/sel90m28g/specifications"
  - "発売日参考: https://www.sony.jp/CorporateCruise/Press/201506/15-0616/"
関連機材:
  - "[[SONY α7Ⅴ|α7Ⅴ]]"
  - "[[SONY α7Ⅳ|α7Ⅳ]]"
  - "[[SONY α7C|α7C]]"
aliases:
  - SONY SEL90M28G
  - SEL90M28G
  - 90mm F2.8
  - 90mm Macro
---

![[SONY SEL90M28G.jpg|400]]

## 公式仕様メモ

- 90mm F2.8のフルサイズEマウント中望遠マクロ。
- 最大撮影倍率1.0xの等倍マクロ。レンズ内手ブレ補正Optical SteadyShot搭載。
- 重量602g、フィルター径φ62mm。防塵・防滴に配慮した設計。

## 主な用途

- マクロ
- ポートレート
- 物撮り
- テーブルフォト
- 花

## 自分の使用感

### 良いところ
- マクロという他にはない表現ができる
- MF/AF切替がかっこいい
- 外観もかっこいい。デザインが好み
- マクロだけでなくポートレートもいける

### 気になるところ
- AF速度が遅め
- 90mmはスナップには向いていない
- 花や虫を撮るためだけにスナップで持ち運ぶには重く億劫になる
- スナップでマクロを撮ろうと思うとどうしてもストロボが欲しくなる

### 向いている撮影
- 花や虫、フィギュアなどのマクロ撮影
- ポートレート
- 他のレンズには出来ない寄りでの表現

### 向いていない撮影
- スナップ

## 使用シーン別メモ

### ポートレート
- 

### コスプレイベント
- 

### スナップ
- 花を撮影したい時は持っていくが、ストロボも必要かも
- AFが遅いので瞬間を切り取るのには不向き

### テーブルフォト・物撮り
- 対象の細部を切り取るのに便利
- 三脚かストロボは必須

## α7Ⅴで使う時のメモ

### よく使うF値
- F7.1
- F11

### AF設定メモ
- コンティニュアスAF
- MF
- DMF

### ホワイトバランス・色味メモ
- ストロボ使用時以外はAWB
- クリエイティブルックはSTがいいかも

## 他レンズとの比較

| 比較対象 | 違い・使い分け |
|---|---|
|  |  |

## 作例・撮影メモ

```dataview
LIST
FROM #photo
WHERE contains(レンズ, this.file.name)
SORT file.ctime DESC
```

## 購入・売却メモ

| 項目 | 内容 |
|---|---|
| 購入日 | 2022/1/19 |
| 購入価格 | ¥106,800 |
| 購入店 | マップカメラ(楽天市場) |
| 保証 |  |
| 売却予定 | false |
| 売却理由 |  |
| 売却価格目安 |  |

## 参照元

| 種別 | URL |
|---|---|
| 公式製品ページ | https://www.sony.jp/ichigan/products/SEL90M28G/ |
| 公式仕様ページ | https://www.sony-asia.com/electronics/camera-lenses/sel90m28g/specifications |
| 発売日参考 | https://www.sony.jp/CorporateCruise/Press/201506/15-0616/ |

## 関連ノート

- [[撮影機材一覧|機材一覧]]
- [[SONY α7Ⅴ|α7Ⅴ]]
