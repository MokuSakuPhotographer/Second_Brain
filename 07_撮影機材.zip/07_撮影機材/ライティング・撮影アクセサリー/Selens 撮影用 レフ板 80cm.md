﻿---
type: reflector
名前: Selens 撮影用 レフ板 80cm
カテゴリ: ライティング・撮影アクセサリー
メーカー: Selens
種類: レフ板
サイズ: 80cm
tags:
  - ライティング
  - 撮影
  - Selens
  - ライティング撮影アクセサリー
aliases:
  - 撮影用 レフ板 80cm
  - Selens 撮影用 レフ板 80cm
  - レフ板
---
![[Selens 80cm Reflector.jpg|400]]


# Selens 撮影用 レフ板 80cm

#ライティング #撮影 #Selens #ライティング撮影アクセサリー

## 基本情報

- **カテゴリ**: ライティング・撮影アクセサリー
- **メーカー**: Selens

## 仕様

- **種類**: レフ板
- **サイズ**: 80cm

## メモ

- 
